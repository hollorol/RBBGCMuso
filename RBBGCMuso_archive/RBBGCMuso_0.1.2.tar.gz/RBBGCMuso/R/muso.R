#' This runs the BBGC-MuSo model
#' @author Roland Hollós
#' @param filename Name of the initialisation files
#' @return No return, outputs are written to file 
#' @usage The function works only, if ...

Linuxp <-(Sys.info()[1]=="Linux")


cleanupMuso <- function(location=NULL,deep=FALSE){
    ## if(location==NULL){
    ##     location=getwd()
    ##}

    if(deep){
        if(dir.exists("LOG")){
        setwd("LOG")
        file.remove(
            grep("(out$)|(endpoint$)|(log$)",
                 list.files(), value = T)
        )}
        
        if(dir.exists("../ERROR")){
        setwd("../ERROR")

        file.remove(
            grep("(out$)|(endpoint$)|(log$)",
                 list.files(), value = T)
        )}
        
        setwd("..")
        file.remove(
            grep("(out$)|(endpoint$)|(log$)",
                 list.files(), value = T)
        )
    }
    
    file.remove(
        grep("(out$)|(endpoint$)|(log$)",
             list.files(), value = T)
    )
    
    
}

rungetMuso <- function(settings,parameters=c(" ECOPHYS"),timee="d",debugging=FALSE,logfilename=NULL){
                                        #spinup run
                                        # changemulline(type=1,setup(), parameters[[2]])
    changemulline(settings,parameters)

    inputloc<-settings$inputloc
    executable<-settings$executable
    ininput<-settings$ininput
    
    
    setwd(inputloc)
    system(paste(executable,ininput[1],sep=" "))
    logspinup<-list.files(inputloc)[grep("log$",list.files(inputloc))]
    spincrash<-tail(readLines(paste(inputloc,logspinup,sep=""),-1),1)==0
    
    if(!spincrash){
        
                                        #normal run
        setwd(inputloc)
        system(paste(executable,ininput[2],sep=" "))
        
        switch(timee,
               "d"=(Reva<-getdailyout(settings)),
               "m"=(Reva<-getmonthlyout(settings)),
               "y"=(Reva<-getyearlyout(settings))
               )
    }

    logfiles<-list.files(inputloc)[grep("log$",list.files(inputloc))]

#############LOG SECTION#######################
    perror<-as.numeric(as.vector(lapply(paste(inputloc,logfiles,sep=""),function(x) tail(readLines(x,-1),1))))
    dirName<-paste(inputloc,"/LOG",sep="")
    dirERROR<-paste(inputloc,"/ERROR",sep="")
    ERROR_EPC<-paste(inputloc,"/ERROR_EPC",sep="")

    if(!dir.exists(dirName)){
        dir.create(dirName)
    }

    if(!dir.exists(dirERROR)){
        dir.create(dirERROR)
    }

    if(length(perror)>sum(perror)){
        errorsign <- 1
    } else {
        errorsign <- 0
    }



    if(debugging=="stamplog"){
        stampnum<-stamp(dirName)
        lapply( logfiles, function (x) file.rename(from=paste(inputloc,x, sep=""), to=paste(dirName, "/",(stampnum+1),"-",x,sep="")))
        if(errorsign==1){
            lapply( logfiles, function (x) file.copy(from=paste(dirName, "/",(stampnum+1),"-",x,sep=""), to=dirERROR  ))}

    } else { if(debugging){
                if(is.null(logfilename)){
                     lapply( logfiles, function (x) file.rename(from=paste(inputloc,x, sep=""), to=paste(dirName,"/", x, sep="")))
                     if(errorsign==1){
                         lapply( logfiles, function (x) file.rename(from=paste(dirName,"/", x, sep=""), to=dirERROR))
                     }

                 } else {
                     lapply( logfiles, function (x) file.rename(from=paste(inputloc,x, sep=""), to=paste(dirName, "/",logfilename,"-",x,sep="")))
                     if(errorsign==1){
                         lapply( logfiles, function (x) file.rename(from=paste(dirName, "/",logfilename,"-",x,sep=""), to=dirERROR))
                     }
                 }    
                 
             }}


    cleanupMuso()
    if(errorsign==1){
        return("Modell Failure")
    }

    
    return(Reva)
}


spinupMuso <- function(settings,parameters=c(" ECOPHYS"),debugging=FALSE,logfilename=NULL){

    changemulline(settings, parameters)

    inputloc<-settings$inputloc
    executable<-settings$executable
    ininput<-settings$ininput
    
    setwd(inputloc)
    system(paste(executable,ininput[1],sep=" "))

    logfiles<-list.files(inputloc)[grep("log$",list.files(inputloc))]
 perror<-as.numeric(as.vector(lapply(paste(inputloc,logfiles,sep=""),function(x) tail(readLines(x,-1),1))))
    dirName<-paste(inputloc,"/LOG",sep="")
    dirERROR<-paste(inputloc,"/ERROR",sep="")
    ERROR_EPC<-paste(inputloc,"/ERROR_EPC",sep="")

    if(!dir.exists(dirName)){
        dir.create(dirName)
    }

    if(!dir.exists(dirERROR)){
        dir.create(dirERROR)
    }

    if(length(perror)>sum(perror)){
        errorsign <- 1
    } else {
        errorsign <- 0
    }



    if(debugging=="stamplog"){
        stampnum<-stamp(dirName)
        lapply( logfiles, function (x) file.rename(from=paste(inputloc,x, sep=""), to=paste(dirName, "/",(stampnum+1),"-",x,sep="")))
        if(errorsign==1){
            lapply( logfiles, function (x) file.copy(from=paste(dirName, "/",(stampnum+1),"-",x,sep=""), to=dirERROR  ))}

    } else { if(debugging){
                if(is.null(logfilename)){
                     lapply( logfiles, function (x) file.rename(from=paste(inputloc,x, sep=""), to=paste(dirName,"/", x, sep="")))
                     if(errorsign==1){
                         lapply( logfiles, function (x) file.rename(from=paste(dirName,"/", x, sep=""), to=dirERROR))
                     }

                 } else {
                     lapply( logfiles, function (x) file.rename(from=paste(inputloc,x, sep=""), to=paste(dirName, "/",logfilename,"-",x,sep="")))
                     if(errorsign==1){
                         lapply( logfiles, function (x) file.rename(from=paste(dirName, "/",logfilename,"-",x,sep=""), to=dirERROR))
                     }
                 }    
                 
             }}


    cleanupMuso()
    if(errorsign==1){
        return("Modell Failure")
    }

    
}


normalMuso<- function(settings,parameters=c(" ECOPHYS"),timee="d",debugging=FALSE,logfilename=NULL){
    changemulline(settings,parameters)

    inputloc<-settings$inputloc
    executable<-settings$executable
    ininput<-settings$ininput




    setwd(inputloc)
                                        #normal run
    system(paste(executable,ininput[2],sep=" "))
    
    switch(timee,
           "d"=(Reva<-getdailyout(settings)),
           "m"=(Reva<-getmonthlyout(settings)),
           "y"=(Reva<-getyearlyout(settings))
           )


    logfiles<-list.files(inputloc)[grep("log$",list.files(inputloc))]

#############LOG SECTION#######################
    perror<-as.numeric(as.vector(lapply(paste(inputloc,logfiles,sep=""),function(x) tail(readLines(x,-1),1))))
    dirName<-paste(inputloc,"/LOG",sep="")
    dirERROR<-paste(inputloc,"/ERROR",sep="")
    ERROR_EPC<-paste(inputloc,"/ERROR_EPC",sep="")

    if(!dir.exists(dirName)){
        dir.create(dirName)
    }

    if(!dir.exists(dirERROR)){
        dir.create(dirERROR)
    }

    if(length(perror)>sum(perror)){
        errorsign <- 1
    } else {
        errorsign <- 0
    }



    if(debugging=="stamplog"){
        stampnum<-stamp(dirName)
        lapply( logfiles, function (x) file.rename(from=paste(inputloc,x, sep=""), to=paste(dirName, "/",(stampnum+1),"-",x,sep="")))
        if(errorsign==1){
            lapply( logfiles, function (x) file.copy(from=paste(dirName, "/",(stampnum+1),"-",x,sep=""), to=dirERROR  ))}

    } else { if(debugging){
                if(is.null(logfilename)){
                     lapply( logfiles, function (x) file.rename(from=paste(inputloc,x, sep=""), to=paste(dirName,"/", x, sep="")))
                     if(errorsign==1){
                         lapply( logfiles, function (x) file.rename(from=paste(dirName,"/", x, sep=""), to=dirERROR))
                     }

                 } else {
                     lapply( logfiles, function (x) file.rename(from=paste(inputloc,x, sep=""), to=paste(dirName, "/",logfilename,"-",x,sep="")))
                     if(errorsign==1){
                         lapply( logfiles, function (x) file.rename(from=paste(dirName, "/",logfilename,"-",x,sep=""), to=dirERROR))
                     }
                 }    
                 
             }}


    cleanupMuso()
    if(errorsign==1){
        return("Modell Failure")
    }

    

    
    return(Reva)

}




## runMuso <- function(settings, parameters=c(" ECOPHYS")){
##                                         #changing section
##                                         #   for(i in changeinput){
##                                         #     changemulline(settings, parameters[[i]])
##                                         #   }
##     changemulline(settings,parameters)

##                                         #spinup run
##                                         # changemulline(type=1,setup(), parameters[[2]])
##     setwd(settings$inputloc)
##     system(paste(settings$executable,settings$ininput[1],sep=" "))
##                                         #normal run
##     setwd(settings$inputloc)
##     system(paste(settings$executable,settings$ininput[2],sep=" "))
## }

## rungetMusowc <- function(settings,parameters=c(" ECOPHYS"),timee="y",logfile=FALSE,logfilename=NULL){
##                                         #spinup run
##                                         # changemulline(type=1,setup(), parameters[[2]])
##     changemulline(settings,parameters)
##     setwd(settings$inputloc)
##     system(paste(settings$executable,settings$ininput[1],sep=" "))
##                                         #normal run
##     setwd(settings$inputloc)
##     system(paste(settings$executable,settings$ininput[2],sep=" "))
    
##     switch(timee,
##            "d"=(Reva<-getdailyout(settings)),
##            "m"=(Reva<-getmonthlyout(settings)),
##            "y"=(Reva<-getyearlyout(settings))
##            )
##     return(Reva)
## }

