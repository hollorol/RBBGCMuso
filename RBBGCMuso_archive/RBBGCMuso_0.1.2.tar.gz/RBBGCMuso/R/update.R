
update<-function(templateIni){
    TEMPL<-readLines(templateIni,-1)

    metpos <- grep("(filename) met file name",TEMPL)
    inrestartpos <- grep("(filename) name of the input restart",TEMPL)
    outrestartpos <- grep("(filename) name of the output restart",TEMPL)
    co2pos <- grep("(filename) name of the CO2 file",TEMPL)
    epcpos <- grep("(filename) EPC file name",TEMPL)
    ndeppos <- grep("(filename) name of the N-dep file",TEMPL)
    ndeppos <- grep("(filename) name of the N-dep file",TEMPL)
    ndeppos <- grep("(filename) name of the N-dep file",TEMPL)
    ndeppos <- grep("(filename) name of the N-dep file",TEMPL)
    ndeppos <- grep("(filename) name of the N-dep file",TEMPL)
    ndeppos <- grep("(filename) name of the N-dep file",TEMPL)
    ndeppos <- grep("(filename) name of the N-dep file",TEMPL)
    

    }
