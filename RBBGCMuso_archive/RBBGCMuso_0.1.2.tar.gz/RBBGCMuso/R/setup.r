#' This runs the BBGC-MuSo model
#' @author Roland Hollós
#' @param calibrationpar vector with line numbers
#' @return No return, outputs are written to file
setup <- function(executable=NULL,
                  parallel = F,
                  calibrationpar =c(1),
                  outputloc=NULL,
                  inputloc=NULL,
                  metinput=NULL,
                  ininput=NULL,
                  epcinput=NULL
                  ){

  Linuxp <-(Sys.info()[1]=="Linux")

    if(is.null(inputloc)){
    inputloc<- "./"
  }
    inp <- unlist(strsplit(inputloc,""))

    if(inp[length(inp)]!="/"){
            inp<-c(inp,"/")
            inputloc <- paste(inp,collapse = "")
            rm(inp)
    }
    
  if(is.null(outputloc)){
    outputloc<-inputloc
    }

  if(is.null(ininput)){
      spinups<-grep("s.ini$",list.files(inputloc),value=TRUE)
      normals<-grep("n.ini$",list.files(inputloc),value=TRUE)

      if(length(spinups)==1){
      ininput[1]<-paste(inputloc,spinups,sep="")
      } else {return(print("There are multiple or no spinup files, please choose"))}
      

      if(length(normals)==1){
      ininput[2]<-paste(inputloc,normals,sep="")
      } else {return(print("There are multiple or no normal files, please choose"))}

  }

    if(is.null(epcinput)){
   epcinput<-paste(inputloc,"oak_Pietsch_muso4_sp.epc",sep="")
    } else{

        }

  if(is.null(metinput)){


      metinput[1]<-paste(inputloc,"foresee_1900-2007_jlug.mtc43",sep="")
    metinput[2]<-paste(inputloc,"CO2_LD_ML_1900-2007.txt",sep="")
    metinput[3]<-paste(inputloc,"Ndep_hhs_1900-2007.txt",sep="")
  } else {

      }


  if(is.null(executable)){
    executable<-paste(inputloc,"muso",sep="")} else {
    file.copy(executable,inputloc)}

  outputname<-unlist(read.table(ininput[2],skip=93,nrows = 1))[1]
  inputfiles<-c(ininput,epcinput,metinput)
  numdata<-rep(NA,3)
  numyears<-unlist(read.table(ininput[2],skip = 14,nrows = 1)[1])
  numvalues<-unlist(read.table(ininput[2],skip=102,nrows = 1)[1])
  numdata[1]<-numyears*numvalues*365
  numdata[2]<-numyears*numvalues*12
  numdata[3]<-numyears*numvalues

  settings = list(executable = executable,
                  calibrationpar = calibrationpar,
                  outputloc=outputloc,
                  outputnames=outputname,
                  inputloc=inputloc,
                  ininput=ininput,
                  metinput=metinput,
                  epcinput=epcinput,
                  inputfiles=inputfiles,
                  numdata=numdata,
                  numyears=numyears
                  )

  return(settings)

}

