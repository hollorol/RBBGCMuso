library(testthat)
library(RBBGCMuso)

test_check("RBBGCMuso")
