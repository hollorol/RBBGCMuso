#soilMatrix <- function(numberOfLayers=)
