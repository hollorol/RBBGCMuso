## #' paramsweep
## #'
## #' This function update the the muso outputcode-variable matrix
## #' @author Roland Hollos
## #' @return The outputcode-variable matrix, and also change the global variable
## #' @import rmarkdown
## #' @export

## paramSweep <- function(inputDir="./",parameters=NULL,outputDir=NULL){

   
##     read.csv(system.file("markdowns","parameters.csv",package="RBBGCMuso"))
## }
